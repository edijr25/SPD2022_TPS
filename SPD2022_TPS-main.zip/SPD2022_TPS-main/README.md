# Sistemas de Procesamiento de Datos

- División 1G.
- Año 2022.

---

## Grupo: SPDnianos
### Integrantes:
- Alejo Martin Carmona.
- Edicilio Lopez.
- Agustina Villarreal.
- Josué Duarte.

---

### Trabajo Práctico N° 1: Cronómetro Binario.
### Link del circuito en Tinkercad: https://www.tinkercad.com/things/dAYGqIH35za

---